/**
 * This package provides annotations that can be used with {@link com.google.gson.Gson}.
 * 
 * @author Inderjeet Singh, Joel Leitch
 */
package com.google.gson.annotations;